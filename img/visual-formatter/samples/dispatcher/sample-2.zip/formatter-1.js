// Enums Declarations
const BarcodeType = {
	NOT_DEFINED: 0,
	CODE39: 1,
	DISCRETE25: 2,
	MATRIX25: 3,
	INTERLEAVED25: 4,
	CODABAR: 5,
	CODE93: 6,
	CODE128: 7,
	UPCA: 8,
	UPCA_ADDON2: 9,
	UPCA_ADDON5: 10,
	UPCE: 11,
	UPCE_ADDON2: 12,
	UPCE_ADDON5: 13,
	UPCE1: 14,
	UPCE1_ADDON2: 15,
	UPCE1_ADDON5: 16,
	EAN13: 17,
	EAN13_ADDON2: 18,
	EAN13_ADDON5: 19,
	EAN8: 20,
	EAN8_ADDON2: 21,
	EAN8_ADDON5: 22,
	MSI: 23,
	GS1_14: 24,
	GS1_LIMIT: 25,
	GS1_EXP: 26,
	PDF417: 27,
	DATAMATRIX: 28,
	MAXICODE: 29,
	TRIOPTIC: 30,
	CODE32: 31,
	MICROPDF417: 32,
	QRCODE: 33,
	AZTEC: 34,
	POSTAL_PLANET: 35,
	POSTAL_POSTNET: 36,
	POSTAL_4STATE: 37,
	POSTAL_ROYALMAIL: 38,
	POSTAL_AUSTRALIAN: 39,
	POSTAL_KIX: 40,
	POSTAL_JAPAN: 41,
	GS1_128: 42,
	CODE39_FULLASCII: 43,
	EAN13_ISBN: 44,
	EAN13_ISSN: 45,
	MICRO_QR: 46,
	COMPOSITE_GS1_128_A: 47,
	COMPOSITE_GS1_128_B: 48,
	COMPOSITE_GS1_128_C: 49,
	COMPOSITE_GS1_14_A: 50,
	COMPOSITE_GS1_14_B: 51,
	COMPOSITE_GS1_LIMIT_A: 52,
	COMPOSITE_GS1_LIMIT_B: 53,
	COMPOSITE_GS1_EXP_A: 54,
	COMPOSITE_GS1_EXP_B: 55,
	COMPOSITE_CC_A: 56,
	COMPOSITE_CC_B: 57,
	DOTCODE: 58,
	ISBT_128: 59,
	ISBT_128_CONCATENATED: 60
}

// Inputs
var barcodeStringIn = getInputObject("barcodeStringIn");

// Outputs
var barcodeStringOut = "";

// Functions
var stringIndexOf3 = function(input, output) {
		if (input["str"] === undefined || input["match"] === undefined)
			return;
		output["index"] = input["str"].indexOf(input["match"]);
	};
var add4 = function(input, output) {
		if (input["in"] === undefined)
			return;
		output["out"] = 0;
		for (var i = 0; i < input["in"].length; i++)
			output["out"] += input["in"][i];
	};
var add5 = function(input, output) {
		if (input["in"] === undefined)
			return;
		output["out"] = 0;
		for (var i = 0; i < input["in"].length; i++)
			output["out"] += input["in"][i];
	};
var subString6 = function(input, output) {
		if (input["inStr"] === undefined || input["idBegin"] === undefined || input["idEnd"] === undefined)
			return;
		output["outStr"] = input["inStr"].substring(input["idBegin"], input["idEnd"]);
	};

// Code flow
var input = new Object();
var output = new Object();
input = new Object();
input.str = barcodeStringIn;
input.match = "00";
output = new Object();
stringIndexOf3(input, output);
stringIndexOf3 = new Object();
stringIndexOf3.index = output.index;
input = new Object();
input.in = [];
input.in[1] = 2.0;
input.in[0] = stringIndexOf3.index;
output = new Object();
add4(input, output);
add4 = new Object();
add4.out = output.out;
input = new Object();
input.in = [];
input.in[1] = 20.0;
input.in[0] = stringIndexOf3.index;
output = new Object();
add5(input, output);
add5 = new Object();
add5.out = output.out;
input = new Object();
input.inStr = barcodeStringIn;
input.idBegin = add4.out;
input.idEnd = add5.out;
output = new Object();
subString6(input, output);
subString6 = new Object();
subString6.outStr = output.outStr;
barcodeStringOut = subString6.outStr;

// Save outputs
putOutputObject("barcodeStringOut", barcodeStringOut);