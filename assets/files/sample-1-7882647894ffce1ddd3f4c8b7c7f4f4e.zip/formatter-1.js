// Enums Declarations
const BarcodeType = {
	NOT_DEFINED: 0,
	CODE39: 1,
	DISCRETE25: 2,
	MATRIX25: 3,
	INTERLEAVED25: 4,
	CODABAR: 5,
	CODE93: 6,
	CODE128: 7,
	UPCA: 8,
	UPCA_ADDON2: 9,
	UPCA_ADDON5: 10,
	UPCE: 11,
	UPCE_ADDON2: 12,
	UPCE_ADDON5: 13,
	UPCE1: 14,
	UPCE1_ADDON2: 15,
	UPCE1_ADDON5: 16,
	EAN13: 17,
	EAN13_ADDON2: 18,
	EAN13_ADDON5: 19,
	EAN8: 20,
	EAN8_ADDON2: 21,
	EAN8_ADDON5: 22,
	MSI: 23,
	GS1_14: 24,
	GS1_LIMIT: 25,
	GS1_EXP: 26,
	PDF417: 27,
	DATAMATRIX: 28,
	MAXICODE: 29,
	TRIOPTIC: 30,
	CODE32: 31,
	MICROPDF417: 32,
	QRCODE: 33,
	AZTEC: 34,
	POSTAL_PLANET: 35,
	POSTAL_POSTNET: 36,
	POSTAL_4STATE: 37,
	POSTAL_ROYALMAIL: 38,
	POSTAL_AUSTRALIAN: 39,
	POSTAL_KIX: 40,
	POSTAL_JAPAN: 41,
	GS1_128: 42,
	CODE39_FULLASCII: 43,
	EAN13_ISBN: 44,
	EAN13_ISSN: 45,
	MICRO_QR: 46,
	COMPOSITE_GS1_128_A: 47,
	COMPOSITE_GS1_128_B: 48,
	COMPOSITE_GS1_128_C: 49,
	COMPOSITE_GS1_14_A: 50,
	COMPOSITE_GS1_14_B: 51,
	COMPOSITE_GS1_LIMIT_A: 52,
	COMPOSITE_GS1_LIMIT_B: 53,
	COMPOSITE_GS1_EXP_A: 54,
	COMPOSITE_GS1_EXP_B: 55,
	COMPOSITE_CC_A: 56,
	COMPOSITE_CC_B: 57,
	DOTCODE: 58,
	ISBT_128: 59,
	ISBT_128_CONCATENATED: 60
}
const EventType = {
	BARCODE: 0,
	START: 1,
	STOP: 2,
	TIMEOUT: 3
}
const KeyCode = {
	A: 29,
	ALT_LEFT: 57,
	ALT_RIGHT: 58,
	APOSTROPHE: 75,
	AT: 77,
	B: 30,
	BACK: 4,
	BACKSLASH: 73,
	BREAK: 121,
	BRIGHTNESS_DOWN: 220,
	BRIGHTNESS_UP: 221,
	C: 31,
	CAPS_LOCK: 115,
	CLEAR: 28,
	COMMA: 55,
	COPY: 278,
	CTRL_LEFT: 113,
	CTRL_RIGHT: 114,
	CUT: 277,
	D: 32,
	DEL: 67,
	E: 33,
	ENTER: 66,
	EQUALS: 70,
	ESCAPE: 111,
	F: 34,
	F1: 131,
	F10: 140,
	F11: 141,
	F12: 142,
	F2: 132,
	F3: 133,
	F4: 134,
	F5: 135,
	F6: 136,
	F7: 137,
	F8: 138,
	F9: 139,
	FORWARD: 125,
	FORWARD_DEL: 112,
	FUNCTION: 119,
	G: 35,
	GRAVE: 68,
	H: 36,
	HOME: 3,
	I: 37,
	INSERT: 124,
	J: 38,
	K: 39,
	L: 40,
	LEFT_BRACKED: 71,
	M: 41,
	MENU: 82,
	META_LEFT: 117,
	META_RIGHT: 118,
	MINUS: 69,
	MOVE_END: 123,
	MOVE_HOME: 122,
	N: 42,
	NUM_0: 7,
	NUM_1: 8,
	NUM_2: 9,
	NUM_3: 10,
	NUM_4: 11,
	NUM_5: 12,
	NUM_6: 13,
	NUM_7: 14,
	NUM_8: 15,
	NUM_9: 16,
	NUM_LOCK: 143,
	O: 43,
	P: 44,
	PAGE_DOWN: 93,
	PAGE_UP: 92,
	PASTE: 279,
	PERIOD: 56,
	PLUS: 81,
	POUND: 18,
	Q: 45,
	R: 46,
	RIGHT_BRACKET: 72,
	S: 47,
	SCROLL_LOCK: 116,
	SEMICOLON: 74,
	SHIFT_LEFT: 59,
	SHIFT_RIGHT: 60,
	SLASH: 76,
	SPACE: 62,
	STAR: 17,
	SYM: 63,
	SYSRQ: 120,
	T: 48,
	TAB: 61,
	U: 49,
	V: 50,
	W: 51,
	X: 52,
	Y: 53,
	Z: 54
}
const IntentType = {
	START_ACTIVITY: 0,
	START_SERVICE: 1,
	SEND_BROADCAST: 2
}

// Inputs
var barcodeStringIn = getInputObject("barcodeStringIn");
var barcodeTypeIn = getInputObject("barcodeTypeIn");

// Outputs
var actionsOut = "";

// Functions
var actionSendBarcode3 = function(input, output) {
		if (input["barcodeString"] === undefined || input["barcodeType"] === undefined)
			return;
		var tmpAction = { type: "Barcode", barcodeString: input["barcodeString"], barcodeType: input["barcodeType"] };
		output["actionId"] = createAction(JSON.stringify(tmpAction));
	};
var actionSendKeyEvent4 = function(input, output) {
		if (input["keyCode"] === undefined || input["pressed"] === undefined)
			return;
		var tmpAction = { type: "KeyEvent", keyCode: input["keyCode"], pressed: input["pressed"] };
		output["actionId"] = createAction(JSON.stringify(tmpAction));
	};
var actionSendKeyEvent5 = function(input, output) {
		if (input["keyCode"] === undefined || input["pressed"] === undefined)
			return;
		var tmpAction = { type: "KeyEvent", keyCode: input["keyCode"], pressed: input["pressed"] };
		output["actionId"] = createAction(JSON.stringify(tmpAction));
	};
var actionSendKeyEvent6 = function(input, output) {
		if (input["keyCode"] === undefined || input["pressed"] === undefined)
			return;
		var tmpAction = { type: "KeyEvent", keyCode: input["keyCode"], pressed: input["pressed"] };
		output["actionId"] = createAction(JSON.stringify(tmpAction));
	};
var actionSendKeyEvent7 = function(input, output) {
		if (input["keyCode"] === undefined || input["pressed"] === undefined)
			return;
		var tmpAction = { type: "KeyEvent", keyCode: input["keyCode"], pressed: input["pressed"] };
		output["actionId"] = createAction(JSON.stringify(tmpAction));
	};
var arrayCreate11 = function(input, output) {
		if (input["element"] === undefined)
			return;
		output["array"] = [];
		for (var i = 0; i < input["element"].length; i++)
			output["array"][i] = input["element"][i];
	};

// Code flow
var input = new Object();
var output = new Object();
input = new Object();
input.barcodeString = barcodeStringIn;
input.barcodeType = barcodeTypeIn;
output = new Object();
actionSendBarcode3(input, output);
actionSendBarcode3 = new Object();
actionSendBarcode3.actionId = output.actionId;
input = new Object();
input.keyCode = KeyCode.CTRL_LEFT;
input.pressed = false;
output = new Object();
actionSendKeyEvent4(input, output);
actionSendKeyEvent4 = new Object();
actionSendKeyEvent4.actionId = output.actionId;
input = new Object();
input.keyCode = KeyCode.A;
input.pressed = false;
output = new Object();
actionSendKeyEvent5(input, output);
actionSendKeyEvent5 = new Object();
actionSendKeyEvent5.actionId = output.actionId;
input = new Object();
input.keyCode = KeyCode.A;
input.pressed = true;
output = new Object();
actionSendKeyEvent6(input, output);
actionSendKeyEvent6 = new Object();
actionSendKeyEvent6.actionId = output.actionId;
input = new Object();
input.keyCode = KeyCode.CTRL_LEFT;
input.pressed = true;
output = new Object();
actionSendKeyEvent7(input, output);
actionSendKeyEvent7 = new Object();
actionSendKeyEvent7.actionId = output.actionId;
input = new Object();
input.element = [];
input.element[0] = actionSendKeyEvent7.actionId;
input.element[1] = actionSendKeyEvent6.actionId;
input.element[2] = actionSendKeyEvent4.actionId;
input.element[3] = actionSendKeyEvent5.actionId;
input.element[4] = actionSendBarcode3.actionId;
output = new Object();
arrayCreate11(input, output);
arrayCreate11 = new Object();
arrayCreate11.array = output.array;
actionsOut = arrayCreate11.array;

// Save outputs
putOutputObject("actionsOut", actionsOut);